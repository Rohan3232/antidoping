const AntiDoping = artifacts.require("AntiDoping");

module.exports = function(deployer) {
  deployer.deploy(AntiDoping);
};
